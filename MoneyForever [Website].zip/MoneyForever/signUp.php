<!DOCTYPE html> 
<html id="html">
    <head>
        <title>Money Forever Network</title>
        <meta charset="8-utf" />
        <html lang="en-US">
        <meta name="viewport" content="width=device-width">
        
        <!-- CSS & Imports-->
        <link rel="stylesheet" href="css/styles.css" />
        <link rel="stylesheet" href="css/signUp.css"/>
    </head>
    <body onload="toBottom2()">
        <header>
            <ul>
                <li>
                    <a href="index.html"><img src = "images/Logo.jpeg"/> </a>
                </li>
                <nav>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="aboutUs.html">ABOUT US</a></li>
                    <li><a href="contactUs.html">CONTACT US</a></li>
                    <li id="currentPage_link"><a href="signUp.php">SIGN UP</a></li>
                    <li><a href="login.php">LOGIN</a></li>
                </nav>
            </ul>
        </header>

        <section class="top_Section">
            <article class="NavigationBAR-2">
                <p> HOME / <span>SIGN UP</span></p>
            </article>

            <article class="background-img">
                    <img src="images/others/join11.jpeg"/>
                    <h1>JOIN THE FAST GROWING NETWORK TODAY</h1>
                    <h2>Then you will be on your way to FINANCIAL FREEDOM</h2>
                    <div class="join">
                        <button onclick="toBottom(1000)"> JOIN NOW</button><br/>
                        <label> Create an account</label>
                    </div>
                    <div class="signIn">
                        <button onclick="toLogin()"> LOGIN</button> <br/>
                        <label> Already have an account?</label>
                    </div>
            </article>
        </section>
            
        <?php
            session_start();
            $usernameDuplicate = ""; 
            $emailDuplicate = "";
            $referal_exist = "";

            $referal = "";
            $fname = "";
            $lname = "";
            $usern = "";
            $email = "";
            $cell =  "";
            $pass = "";
            $passC="";
            $jsValidated = "";
            $scrollValue = ""; 

            if ($_SERVER["REQUEST_METHOD"] == "POST") 
            {
                // Error reporting
                
                // Database
                $servername = "localhost";
                $username = "root";
                $password = "root";
                $dbname = "FaMoneyForever";

                // Create connection
                $conn = mysqli_connect($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) 
                {
                    die("Connection failed: " . $conn->connect_error);
                } 

                $referal = $_POST["referal"];
                $fname = $_POST["firstname"];
                $lname = $_POST["lastname"];
                $usern = $_POST["username"];
                $email = $_POST["email"];
                $cell =  $_POST["cellphone"];
                $pass = $_POST["password"];
                $passC = $_POST["conf_pass"];
                $jsValidated = $_POST["JsValidated"];
                $scrollValue = $_POST["scrollV"]; 

                $sql = "SELECT username, referalID, email FROM Members";
                $result = $conn->query($sql);
    
                $username_passed = true;
                $email_passed = true;
                $referal_passed = false;

                if ($result->num_rows > 0) 
                {
                    // output data of each row
                    
                    while($row = $result->fetch_assoc()) 
                    {
                        if(strtolower($row["referalID"]) === strtolower($referal))
                            $referal_passed = true;

                        
                        if(strtolower($row["username"]) === strtolower($usern))
                        {
                            $usernameDuplicate = "This username already exist! try another";
                            $username_passed = false;
                        }   
                        if(strtolower($row["email"]) === strtolower($email))
                        {
                            $emailDuplicate = "This email has been registered!";
                            $email_passed = false;
                        }
                    }
                }

                if(!empty($referal) && !$referal_passed)
                {
                    $referal_exist = "This referal doesn't exist!";
                }

                if($username_passed && !$email_passed)
                    $usernameDuplicate = "";

                if(!$username_passed && $email_passed)
                    $emailDuplicate = "";

                $jsValidated = $_POST["JsValidated"];
                
                $uniqueCred = $username_passed && $email_passed; 
                $jsValid = $jsValidated == "true";

                if($jsValid && $uniqueCred)
                {
                    if(!empty($referal) && !$referal_passed)
                    {
                        $referal_exist = "This referal doesn't exist!";
                        $referal = "";
                    }

                    $sql = "INSERT INTO Members (memberID,username,referalID,sponserID,firstname, lastname,email, cellphone, password) 
                            VALUES (NULL, '$usern','','$referal','$fname', '$lname','$email','$cell' ,'$pass' )";
    
                    $result = $conn->query($sql);

                    if ($result == TRUE) 
                    {
                        $sql = "SELECT memberID FROM Members WHERE username = '$usern'";  
                        $result = $conn->query($sql);

                        if($result == TRUE)
                        {
                            $ID = $result->fetch_assoc();
                            $refID = "fa-" . ((int)$ID["memberID"] * rand(1,9) + 5) . $usern;

                            $sql = "UPDATE Members SET referalID = '$refID' WHERE username = '$usern'";
                            $result = $conn->query($sql);
                            if($result == TRUE)
                            {
                                $_SESSION["username"] = $usern;
                                header('Location: memberPortal.php');
                                exit;
                            }
                        }
                       
                    } 
                    else 
                    {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }

                $conn->close();
            }
        ?>

        <section class="signUp_Section">
            <h1> Create a new account</h1>
            <article class="signUp">
                <form id="form1" name="signUp" onsubmit="return validateForm()" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">   
                
                <table>
                    <tr><td></td>
                        <td><label id="emptyField_validate" hidden="true"> Please fill all required fields! </label></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td> <label class="cell_lbls"> Referal </label> </td>
                        <td> <input class="input_cells" name="referal" id="referal" type="text" value="<?php echo $referal;?>"/></td>
                        <td> <label id="referal_validate" class="error_lbls"><?php echo $referal_exist;?></label></td>
                    </tr>
                    <tr>
                        <td> <label class="cell_lbls"> Firstname </label> </td>
                        <td> <input class="input_cells" name="firstname" id="firstname" type="text" value="<?php echo $fname;?>"/></td>
                        <td> <label id="firstname_validate" hidden="true" class="error_lbls"> Your name cannot contain numbers</label></td>
                    </tr>
                    <tr>
                        <td> <label class="cell_lbls"> Lastname </label> </td>
                        <td> <input class="input_cells" name="lastname" id="lastname" type="text" value="<?php echo $lname;?>"/></td>
                        <td> <label id="lastname_validate" hidden="true" class="error_lbls"> Your surnname cannot contain numbers</label></td>                    
                    </tr>
                     <tr>
                         <td> <label class="cell_lbls"> Username </label> </td>
                         <td> <input class="input_cells" name="username" id="username" type="text" value="<?php echo $usern;?>"/></td>
                         <td> <Label style="color:red;"> <?php echo $usernameDuplicate;?></Label>
                     </tr>
                     <tr>
                         <td> <label class="cell_lbls"> Email </label> </td>
                         <td><input class="input_cells" name="email" id="email" type="email" value="<?php echo $email;?>"/></td>
                         <td> <Label style="color:red;"> <?php echo $emailDuplicate;?></Label></td>
                     </tr>
                     <tr>
                         <td> <label class="cell_lbls"> Cellphone </label> </td>
                         <td><input class="input_cells" name="cellphone" id="cellphone" type="tel" size="10" maxlength="10" value="<?php echo $cell;?>"></td>
                         <td> <label id="cell_validate" hidden="true" class="error_lbls"> this cellphone number is invalid</label></td>
                     </tr>
                     <tr>
                        <td> <label class="cell_lbls"> Password </label> </td>
                        <td><input class="input_cells" name="password" id="password" type="password" value="<?php echo $pass;?>"/></td>
                        <td> <input type="checkbox" onclick="TogglePassword()" id="checkB"> <span id="checkBox_lbl">Show Password</span></td>
                    </tr>
                    <tr>
                        <td> <label class="cell_lbls"> Confirm Password </label> </td>
                        <td><input class="input_cells" name="conf_pass" id="conf_pass" type="password" value="<?php echo $passC;?>"></td>
                        <td> <label id="password_validate" hidden="true" class="error_lbls"> passwords don't match!</label></td>
                    </tr>
                 </table>
                 <p> I have accepted terms and conditions 
                     <input name="terms" id="terms" type="checkbox"/>
                     <label id="terms_validate" hidden="true" class="error_lbls">Please check this to proceed!</label>
                </p>
                   <button id="submit"> Sign Up</button>
                   <input type="text" name="JsValidated" id="jsValidate"  value="<?php echo $jsValidated;?>" hidden="true"/>
                   <input type="text" name="scrollV" id="scrollV"  value="<?php echo $scrollValue;?>" hidden="true"/>
                </form>
            </article>
        </section>
        <br />
        <br />
        <footer>
            <p> Fine Art Money Forever &copy; 2019</p>
        </footer>

    </body>
    <script src="js/signUp.js"></script>
    <script src="js/login.js"></script>
</html>
