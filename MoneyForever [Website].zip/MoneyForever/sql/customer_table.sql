create table FaMoneyForever.Customers
(
	customerID int auto_increment primary,
    firstname varchar(50),
    lastname varchar(50),
    username varchar(30),
    email varchar(30),
    cellphone varchar(15),
    password varchar(30)
);