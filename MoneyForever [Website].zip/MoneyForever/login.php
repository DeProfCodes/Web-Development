<!DOCTYPE html> 
<html>
    <head>
        <title>Money Forever Network</title>
        <meta charset="8-utf" />
        <html lang="en-US">
        <meta name="viewport" content="width=device-width">

        <link rel="icon" href="images/Logo.jpeg" type="image/gif">
        <!-- CSS & Imports-->
        <link rel="stylesheet" href="css/styles.css" />
        <link rel="stylesheet" href="css/login.css" />
    </head>
    <body>
        <header>
            <ul>
                <li>
                    <a href="index.html"><img src = "images/Logo.jpeg"/> </a>
                </li>
                <nav>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="aboutUs.html">ABOUT US</a></li>
                    <li><a href="contactUs.html">CONTACT US</a></li>
                    <li><a href="signUp.php">SIGN UP</a></li>
                    <li id="currentPage_link"><a href="login.php">LOGIN</a></li>
                </nav>
            </ul>
        </header>
    
        <?php
            session_start();
            $wrongPassword = "";
            $wrongUsername = "";

            if ($_SERVER["REQUEST_METHOD"] == "POST") 
            {
                // Error reporting
                $usern = $_POST["username"];
                $pass = $_POST["password"];
                
                if(empty($usern))
                {
                    $wrongUsername = "Please enter username!";
                }
                if(empty($pass))
                {
                    $wrongPassword = "Please enter password!";
                }

                if(!empty($usern))
                {
                    // Database
                    $servername = "localhost";
                    $username = "root";
                    $password = "root";
                    $dbname = "FaMoneyForever";

                    // Create connection
                    $conn = mysqli_connect($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) 
                    {
                        die("Connection failed: " . $conn->connect_error);
                    } 
    
                    $sql = "SELECT username, email, password FROM Members";
                    $result = $conn->query($sql);
    
                    $username_passed = false;
                    $password_passed = false;

                    if ($result->num_rows > 0) 
                    {
                        // search data of each row
                        while($row = $result->fetch_assoc()) 
                        {
                            if((strtolower($row["username"]) == strtolower($usern) ||
                                strtolower($row["email"]) == strtolower($usern)) 
                                && $row["password"] == $pass)
                            {
                                $username_passed = true;
                                $password_passed = true;

                                $_SESSION["username"] = $usern;
                                if(strtolower($row["username"]) == strtolower($usern))
                                    $_SESSION["username_type"] = "username";
                                else
                                    $_SESSION["username_type"] = "email";
                                    
                                break;
                            }
                            else if($row["username"] == $usern || $row["email"] == $usern)
                            {
                               $username_passed = true;
                               break;
                            }
                        }
                    }

                    if($username_passed && !$password_passed && !empty($pass))
                        $wrongPassword = "Incorrect password!";

                    if(!$username_passed)
                        $wrongUsername = "Username doesn't exist!";

                    
                    if ($username_passed && $password_passed) 
                    {
                        header('Location: memberPortal.php');
                        exit;
                    }
                    $conn->close();
                }
            }
        ?>
    
        <section id="Login">
            <form name="Login" onsubmit="LogIn()" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <p id="Title">Log in to your Account</p>
                <br />
                <Label class="labels">Username </Label> <br/>
                <input name="username" id="username" type="text" placeholder="enter username or email" value="<?php echo $usern;?>"/> <br/>
                <Label id="wrongUsername"> <?php echo $wrongUsername;?></Label>
                <br/>
                <label class="labels"> Password </label> <br/>
                <input name="password" id="password" type="password" value="<?php echo $pass;?>"/>
                <input type="checkbox" onclick="TogglePassword()"> <span id="checkBox_lbl">Show Password</span>
                <Label id="wrongPassword"> <?php echo $wrongPassword;?></Label>
                <br/>
                <br/>
                <button id="submit"> LOG IN</button>
                <br/>
                <p> <a href="#">Forgot your password?</a></p>
                <p>Don't have an account? <a href="#">Register now</a></p>
            </form>
        </section>
        <footer>
            <p> Fine Art Money Forever &copy; 2019</p>
        </footer>
    </body>

    <script src="js/login.js"></script>
</html>
