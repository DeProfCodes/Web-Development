<!DOCTYPE html> 
<html>
    <head>
        <title>Member Portal</title>
        <meta charset="8-utf" />
        <html lang="en-US">
        <meta name="viewport" content="width=device-width">
        
        <link rel="icon" href="images/Logo.jpeg" type="image/gif">
        <!-- CSS & Imports-->
        <link rel="stylesheet" href="css/styles_In.css" />
        <link rel="stylesheet" href="css/memberPortal.css" />
    </head>
    <body onload="Load()">
        <header>
            <ul>
                <li>
                    <a href="index.html"><img src = "images/logo2.png"/> </a>
                </li>
                <nav>
                    <li id="currentPage_link"><a href="memberPortal.php">PORTAL</a></li>
                    <li><a href="#">MAKE PAYMENT</a></li>
                    <li ><a href="#">WITHDRAW</a></li>
                    <li><a href="#">DOWN LINES</a></li>
                    <li><a href="#">MATCHING BONUS</a></li>
                    <li><a href="contactUs.html">CONTACT US</a></li>
                    <li>  
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
                            <input type="submit" value ="LOGOUT" id="logout"/> 
                        </form>
                    </li>
                </nav>
            </ul>
        </header>

        <?php
            session_start();
            $referalID = "";
            $fname = "";
            $lname = "";
            $usern_type = $_SESSION["username_type"]; 
            $usern = $_SESSION["username"]; 

            if($usern == "")
            {
                header("location: login.php");
                exit;
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST") 
            {
                $_SESSION["username"] = ""; 
                header("location: index.html");
                exit;
            }
            
            // Database
            $servername = "localhost";
            $username = "root";
            $password = "root";
            $dbname = "FaMoneyForever";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) 
                {
                    die("Connection failed: " . $conn->connect_error);
                } 
    
            $sql = "SELECT firstname, lastname, referalID FROM Members WHERE $usern_type = '$usern'";
            $result = $conn->query($sql);
   
            if ($result->num_rows > 0) 
                {
                    $row = $result->fetch_assoc();
                    $referalID = $row["referalID"];
                    $fname = $row["firstname"];
                    $lname = $row["lastname"];
                }
            $conn->close();
            
           
        ?>

        <section class="body">
            <h1 id="title"> Welcome <span style="color: rgb(36, 196, 36);"> <?php echo $fname . " " . $lname?></span> to your Portal</h1>

            <section class="memberSpace">
                <br>
                <article class="stats">
                    <table id="table1">
                        <tr>
                            <td><Label class="Toplabels"> CURRENT LEVEL </Label> </td>
                            <td> <span>:</span> <Label id="level"> Bronze Level 1 </Label> </td>
                        </tr>
                        <tr>
                            <td><Label class="Toplabels"> No. of people left to complete Level </Label> </td>
                            <td> <span>:</span> <Label id="network"> 2</Label> </td>
                        </tr>
                    </table>
                    <table id="table2">
                        <tr>
                            <td><Label class="Toplabels"> BALANCE  </Label> </td>
                            <td> <span>:</span> <label id="balance"> R200</label></td>
                        </tr>
                        <tr>
                            <td><Label class="Toplabels"> Days Left for Monthly Salary  </Label> </td>
                            <td> <span>:</span> <label id="duration"> 29</label></td>
                        </tr>
                    </table>
                </article>
                <br>

                <article class="referals">
                    <h1>Refer People To Join Under Your network</h1>
                    <p> When someone join under your under your network,
                        They must use your <strong>referal ID</strong> below so you can get a reward
                        for finding a new member to this amaizing network. 
                    </p> 
                    <br>
                    <label class="referals-Labels">Referal ID:</label>
                    <label id="referalID"> <?php echo $referalID ?>  </label>
                    <br>
                    <br>
                    <p> Another popular way you can
                        use to invite your friends is by sharing on popular social media
                    </p>
                    <div style="margin: 1% 0 0 25%; font-size:1.5em"> Share your link on social media :</div>
                    <div class="sharing-methods">
                        
                        <a href="https://wa.me/0737942244/?text=urlencodedtext">
                            <img src="images/whatsapp.png" class="shareIcons"/>
                        </a>
                        <a href="https://wa.me/0737942244/?text=urlencodedtext">
                            <img src="images/facebook.png" class="shareIcons"/>
                        </a>
                        <a href="https://wa.me/0737942244/?text=urlencodedtext">
                            <img src="images/instagram.png" class="shareIcons"/>
                        </a>
                    </div>
                </article>

                <article class="actions">
                    <button id="addMember" onclick="testing()"> Register a member</button> 
                    <button id="finHistory"> Check Transaction History</button>
                    <button id="reward"> Claim Reward</button>       
                </article>
                 <br>
                <br>
            </section>
        </section>

        <footer>
            <p> Fine Art Money Forever &copy; 2019</p>
        </footer>

        <script src="js/portal.js"></script>
    </body>
</html>
