function testing()
{
    alert(sessionStorage["username"]);
    sessionStorage.removeItem("username");
}