function TogglePassword() 
{
    var x = document.getElementById("password");
    if (x.type === "password") 
    {
      x.type = "text";
    } 
    else 
    {
      x.type = "password";
    }
}

function LogIn()
{
  var getUser = sessionStorage.getItem("username");
  if(getUser == null && username!="")
  {
    var username = document.getElementById("username");
    sessionStorage.setItem("username", username.value);
  }

  return true;
}