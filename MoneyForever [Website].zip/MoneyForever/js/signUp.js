function toBottom(height) 
{
  document.body.scrollTop = height;
  document.documentElement.scrollTop = height;
}

function toLogin()
{
  location.replace("login.php");
}

//========================================= VALIDATION FUNCTIONS ======================
//============================================          ===============================
var emptyField = "border: 1px solid red";
var invalid_style = "color: red";

function HideErrorLabels(error_lbls)
{
    for(let i=0; i<error_lbls.length; i++)
    {
        error_lbls[i].hidden = true;
    }
}

function ResetTextBoxs(textBoxes)
{
    for(let i=0; i<textBoxes.length; i++)
    {
        textBoxes[i].style = "border: 1px solid green;";
    }
}

function IsNameValid(name)
{
    var name_str = ""+name.value;
    var invalids = "123456789/*-+=)(&^%$#@!~`<>?/'\'|"; 
    for(let i=0; i<invalids.length; i++)
    {
      if(name_str.indexOf(""+invalids[i]) >=0)
         return false;
    }

    return true;
}

function IsEmptyField(Field, empty)
{
    var field = ""+Field.value;
    if(field=="")
    {
      Field.style = emptyField;
      empty.hidden = false; 
      empty.style = invalid_style;
      return true;
    }
    return false;
}

function validateName(name, name_validate, empty)
{ 
   if(IsEmptyField(name, empty))
   {
      return true;
   }
   
   else if(!IsNameValid(name))
   {
      name_validate.hidden = false;
      name_validate.style = invalid_style;
      return false;
   }
   return true;
}

function validateCell(Cell, cell_validate, empty)
{
  if(IsEmptyField(Cell, empty))
  {
    return false;
  }
  else
  {
     var cell = ""+Cell.value;
     var pattern = cell[0] + cell[1]; 
    
     if(pattern !="01" && pattern !="07" && pattern !="06" && pattern !="08" && 
        pattern !="04" && pattern !="03" && pattern !="02")
        {
          cell_validate.hidden = false;
          cell_validate.style = invalid_style;
          return false;
        }
  }

  return true;
}

function validatePassword(pass, passConf, password_validate, empty)
{
   if(IsEmptyField(passConf, empty))
   {
      return false;
   }
   else if(pass.value != passConf.value)
   {
      password_validate.hidden = false;
      password_validate.style = invalid_style;
      return false;
   }

   return true;
}

function checkBoxChecked(terms, terms_validate)
{
    if(!terms.checked)
    {
        terms_validate.hidden = false;
        terms_validate.style = invalid_style;
        return false;
    }
    return true;
}

function Filled(textBoxes)
{
   for(let i=0; i<textBoxes.length; i++)
    {
        if(textBoxes[i].value.length > 0)
        {
           return true;
        }
    }

    return false;
}

var jsValidated = false;

// Validation failed? Re-edit textboxes and display error labels
function toBottom2()
{ 
  var referal = document.getElementById("referal");
  var fname = document.getElementById("firstname");
  var lname = document.getElementById("lastname");
  var username = document.getElementById("username");
  var email = document.getElementById("email");
  var cell = document.getElementById("cellphone");
  var pass = document.getElementById("password");
  var passConf = document.getElementById("conf_pass");
  var terms = document.getElementById("terms");
  var scrollTo = document.getElementById("scrollV");
  
  var scrollV = parseInt(scrollTo.value);
  
  var fname_validate = document.getElementById("firstname_validate");
  var lname_validate = document.getElementById("lastname_validate");
  var cell_validate = document.getElementById("cell_validate");
  var password_validate = document.getElementById("password_validate");
  var emptyF = document.getElementById("emptyField_validate");
  var passConf = document.getElementById("conf_pass");

  var textBoxes = [referal,fname, lname, username, email, cell, pass, passConf];
  
  var html = document.getElementById("html");

  if(Filled(textBoxes))
  {  
    html.style.scrollBehavior="auto";
    toBottom(scrollV);
    
    terms.checked = true;

    validateName(fname, fname_validate ,emptyF);
    validateName(lname, lname_validate ,emptyF);
    validateCell(cell, cell_validate, emptyF);
    IsEmptyField(pass, emptyF);
    validatePassword(pass, passConf, password_validate, emptyF);
    IsEmptyField(email, emptyF);
    IsEmptyField(username, emptyF);
  }
}

// ============================================== FORM VALIDATION ============================//

function validateForm()
{ 
  var fname = document.getElementById("firstname");
  var lname = document.getElementById("lastname");
  var username = document.getElementById("username");
  var email = document.getElementById("email");
  var cell = document.getElementById("cellphone");
  var pass = document.getElementById("password");
  var passConf = document.getElementById("conf_pass");
  var terms = document.getElementById("terms");
  var referal = document.getElementById("referal");

  var textBoxes = [fname, lname, username, email, cell, pass, passConf, terms];
  ResetTextBoxs(textBoxes);

  var fname_validate = document.getElementById("firstname_validate");
  var lname_validate = document.getElementById("lastname_validate");
  var cell_validate = document.getElementById("cell_validate");
  var password_validate = document.getElementById("password_validate");
  var terms_validate = document.getElementById("terms_validate");
  var emptyF = document.getElementById("emptyField_validate");
  
  var jsValid = document.getElementById("jsValidate");
  var scrollTo = document.getElementById("scrollV");
  
  if(document.documentElement.scrollTop !=0)
    scrollTo.value = document.documentElement.scrollTop;
  else
    scrollTo.value = document.body.scrollTop;

  var error_lbls = [fname_validate, lname_validate, cell_validate, 
                    password_validate, terms_validate ,emptyF];
  HideErrorLabels(error_lbls);

  var valid_usern = !IsEmptyField(username, emptyF); 
  var valid_email = !IsEmptyField(email, emptyF);

  var validfName = validateName(fname, fname_validate ,emptyF);
  var validlName = validateName(lname, lname_validate ,emptyF);
  var validCell = validateCell(cell, cell_validate, emptyF);
  var pasw = !IsEmptyField(pass, emptyF);
  var validPass = validatePassword(pass, passConf, password_validate, emptyF);
  var termsAccepted = checkBoxChecked(terms, terms_validate);

  var allValidated = validfName && validlName && validCell && pasw && 
                     validPass && valid_email && validPass && termsAccepted;
  
  if(allValidated)  // Everything is good to go, proceed to php to insert the account record into database
  { 
    jsValid.value = "true";

    sessionStorage.setItem("username", username.value);

    return true;
  }
  
  if(!termsAccepted)
  {
    return false;
  }
  // If Username and/or Email are empty, stop the page from requesting the php!
  if(!valid_usern && !valid_email)
  {
      return false;
  }
  // Allow a bypass to go to server to validate email or username
  return true;  
}
